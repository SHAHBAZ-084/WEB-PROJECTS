<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    protected $fillable = [
        'user_id',
        'job_title',
        'job_description',
        'skills',
        'career_level',
        'positions',
        'location',
        'qualification',
        'qualification_level',
        'min_experience',
        'max_experience',
        'industry',
        'functional_area',
        'salary_from',
        'salary_to',
        'salary_visible',
        'gender_pref',
        'custom_questions',
        'authorize',
        'start_date',
        'last_date',
    ];

    //
}
