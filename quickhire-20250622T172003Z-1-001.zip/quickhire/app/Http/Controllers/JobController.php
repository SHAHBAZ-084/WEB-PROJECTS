<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JobController extends Controller
{
    public function store(\Illuminate\Http\Request $request)
    {
        $validated = $request->validate([
            'job_title' => 'required|string|max:255',
            'job_description' => 'required|string',
            'skills' => 'required|string',
            'career_level' => 'required|string',
            'positions' => 'required|integer',
            'location' => 'required|string',
            'qualification' => 'required|string',
            'qualification_level' => 'required|string',
            'min_experience' => 'required|integer',
            'max_experience' => 'required|integer',
            'industry' => 'required|string',
            'functional_area' => 'required|string',
            'salary_from' => 'required|integer',
            'salary_to' => 'required|integer',
            'salary_visible' => 'required',
            'gender_pref' => 'nullable|string',
            'custom_questions' => 'nullable',
            'authorize' => 'required',
            'start_date' => 'required|date',
            'last_date' => 'required|date|after_or_equal:start_date',
        ]);
        $validated['user_id'] = auth()->id();
        $validated['salary_visible'] = $request->salary_visible === 'yes' ? 1 : 0;
        $validated['custom_questions'] = $request->has('custom_questions') ? 1 : 0;
        $validated['authorize'] = $request->has('authorize') ? 1 : 0;
        $validated['start_date'] = $request->start_date;
        $validated['last_date'] = $request->last_date;
        \App\Models\Job::create($validated);
        return redirect('/dashboard')->with('success', 'Job posted successfully!');
    }

    public function apply($id)
    {
        $user = auth()->user();
        if ($user->user_type !== 'seeker') {
            return redirect()->back()->with('error', 'Only jobseekers can apply.');
        }
        $job = \App\Models\Job::findOrFail($id);
        $alreadyApplied = \App\Models\JobApplication::where('job_id', $id)->where('user_id', $user->id)->exists();
        if ($alreadyApplied) {
            return redirect()->back()->with('error', 'You have already applied for this job.');
        }
        \App\Models\JobApplication::create([
            'job_id' => $id,
            'user_id' => $user->id,
        ]);
        return redirect()->back()->with('success', 'Successfully applied!');
    }
}
