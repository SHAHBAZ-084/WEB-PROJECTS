<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\JobController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/jobs/create', function () {
    return view('jobs.create');
})->middleware(['auth']);

Route::post('/jobs', [JobController::class, 'store'])->middleware(['auth']);

Route::post('/jobs/{id}/apply', [JobController::class, 'apply'])->middleware(['auth']);

Route::get('/jobs/{id}/apply', function () {
    return redirect('/dashboard');
})->middleware(['auth']);

require __DIR__.'/auth.php';
