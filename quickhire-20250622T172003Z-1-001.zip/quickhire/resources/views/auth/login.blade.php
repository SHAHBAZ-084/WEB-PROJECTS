@php($customBg = 'background: #f5f7fa; min-height: 100vh;')
<div style="{{ $customBg }} display: flex; align-items: center; justify-content: center;">
    <div style="max-width: 600px; width: 100%; margin: 40px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 16px #e0e0e0; padding: 32px 32px 18px 32px;">
        <div style="text-align: center; margin-bottom: 18px;">
            <img src="/quickhire.jpg" alt="quickhire Logo" style="height: 80px; margin-bottom: 10px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <div style="font-size: 28px; font-weight: bold; color: #197080; margin-bottom: 4px; letter-spacing: 1px;">Welcome back!</div>
            <div style="font-size: 18px; color: #555; margin-bottom: 18px;">Sign in to your account to continue</div>
        </div>
        <!-- Session Status -->
        <x-auth-session-status class="mb-4" :status="session('status')" />
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <!-- Email Address -->
            <div style="margin-bottom: 16px;">
                <label for="email" style="display:block; font-weight:500; margin-bottom:6px;">Email</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('email')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <!-- Password -->
            <div style="margin-bottom: 16px;">
                <label for="password" style="display:block; font-weight:500; margin-bottom:6px;">Password</label>
                <input id="password" name="password" type="password" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('password')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <!-- Remember Me -->
            <div style="margin-bottom: 16px; display: flex; align-items: center;">
                <input id="remember_me" type="checkbox" name="remember" style="margin-right: 8px;">
                <label for="remember_me" style="font-size: 15px; color: #333;">RememberMe</label>
            </div>
            <button type="submit" style="width:100%; background:#00687a; color:#fff; border:none; border-radius:6px; padding:12px 0; font-size:18px; font-weight:600; margin-bottom:10px;">Login</button>
            @if (Route::has('password.request'))
                <div style="margin-top: 6px;">
                    <a href="{{ route('password.request') }}" style="color:#00687a; text-decoration:underline; font-size: 15px;">Forgot Password?</a>
                </div>
            @endif
        </form>
        <div style="text-align:center; margin-top: 18px; font-size: 15px;">
            Don't have an account? <a href="#" style="color:#00687a; font-weight:600; text-decoration:underline;">Sign up as JobSeeker</a> / <a href="{{ route('register') }}" style="color:#00687a; font-weight:600; text-decoration:underline;">Sign up as Employer</a>
        </div>
    </div>
</div>
