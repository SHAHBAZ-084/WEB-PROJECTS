@php($customBg = 'background: #f5f7fa; min-height: 100vh;')
<div style="{{ $customBg }} display: flex; align-items: center; justify-content: center;">
    <div style="max-width: 600px; width: 100%; margin: 40px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 16px #e0e0e0; padding: 32px 32px 18px 32px;">
        <div style="text-align: center; margin-bottom: 18px;">
            <img src="/quickhire.jpg" alt="quickhire Logo" style="height: 80px; margin-bottom: 10px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <div style="font-size: 28px; font-weight: bold; color: #197080; margin-bottom: 4px; letter-spacing: 1px;">Welcome to quickhire!</div>
            <div style="font-size: 18px; color: #555; margin-bottom: 18px;">Sign up as an Employer or Job Seeker</div>
        </div>
        <form method="POST" action="{{ route('register') }}">
            @csrf
            <!-- User Type Radios -->
            <div style="margin-bottom: 18px; display: flex; gap: 30px; align-items: center; justify-content: center;">
                <label style="font-size: 16px; cursor: pointer;">
                    <input type="radio" name="user_type" value="seeker" id="seeker" required style="margin-right: 6px;" onclick="toggleOrgField()"> Register as Job Seeker
                </label>
                <label style="font-size: 16px; cursor: pointer;">
                    <input type="radio" name="user_type" value="employer" id="employer" required style="margin-right: 6px;" onclick="toggleOrgField()"> Register as Employer
                </label>
            </div>
            <div id="orgField" style="margin-bottom: 16px; display: none;">
                <label for="organization_name" style="display:block; font-weight:500; margin-bottom:6px;">Organization Name</label>
                <input id="organization_name" name="organization_name" type="text" value="{{ old('organization_name') }}" style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('organization_name')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <script>
                function toggleOrgField() {
                    var seeker = document.getElementById('seeker');
                    var employer = document.getElementById('employer');
                    var orgField = document.getElementById('orgField');
                    if (employer.checked) {
                        orgField.style.display = 'block';
                        document.getElementById('organization_name').required = true;
                    } else {
                        orgField.style.display = 'none';
                        document.getElementById('organization_name').required = false;
                    }
                }
                // On page load, set correct visibility
                window.onload = function() {
                    toggleOrgField();
                };
            </script>
            <!-- Mobile Phone Number -->
            <div style="margin-bottom: 16px;">
                <label for="mobile" style="display:block; font-weight:500; margin-bottom:6px;">Mobile Phone Number</label>
                <input id="mobile" name="mobile" type="text" value="{{ old('mobile') }}" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('mobile')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <!-- Email -->
            <div style="margin-bottom: 16px;">
                <label for="email" style="display:block; font-weight:500; margin-bottom:6px;">Email</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('email')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <!-- Password -->
            <div style="margin-bottom: 16px;">
                <label for="password" style="display:block; font-weight:500; margin-bottom:6px;">Password</label>
                <input id="password" name="password" type="password" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('password')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <!-- Confirm Password -->
            <div style="margin-bottom: 24px;">
                <label for="password_confirmation" style="display:block; font-weight:500; margin-bottom:6px;">Confirm password</label>
                <input id="password_confirmation" name="password_confirmation" type="password" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                @error('password_confirmation')<div style="color:#e74c3c; font-size:13px;">{{ $message }}</div>@enderror
            </div>
            <button type="submit" style="width:100%; background:#00687a; color:#fff; border:none; border-radius:6px; padding:12px 0; font-size:18px; font-weight:600; margin-bottom:10px;">Register</button>
        </form>
        <div style="text-align:center; margin-top: 10px; font-size: 15px;">
            Already have an account? <a href="{{ route('login') }}" style="color:#00687a; text-decoration:underline;">Sign in</a>
        </div>
    </div>
</div>
