@php($user = Auth::user())
@php($isEmployer = $user && $user->user_type === 'employer')
@php($jobs = $isEmployer ? \App\Models\Job::where('user_id', $user->id)->latest()->get() : \App\Models\Job::latest()->get())
@if(session('success'))
    <div style="background:#d4edda; color:#155724; padding:12px 20px; border-radius:6px; margin-bottom:18px; font-size:18px;">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div style="background:#f8d7da; color:#721c24; padding:12px 20px; border-radius:6px; margin-bottom:18px; font-size:18px;">{{ session('error') }}</div>
@endif
<style>
    nav.bg-white.border-b {
        display: none !important;
    }
</style>
<x-app-layout>
    <x-slot name="header">
        <div style="width:100%; background:#fff; display:flex; align-items:center; justify-content:space-between; padding:14px 38px 14px 24px; box-shadow:0 2px 8px rgba(0,0,0,0.04); border-bottom:1.5px solid #e0e0e0;">
            <div style="display:flex; align-items:center; gap:12px;">
                <img src="/quickhire.jpg" alt="quickhire Logo" style="height:48px; width:48px; border-radius:8px; object-fit:cover; box-shadow:0 1px 4px rgba(0,0,0,0.08);">
                <span style="font-size: 26px; font-weight: bold; color: #197080; letter-spacing: 1px;">quickhire</span>
            </div>
            <div style="font-size: 20px; color: #197080; font-weight: 500; text-align:center; flex:1;">
                Welcome to quickhire! Your career journey starts here.
            </div>
            <form method="POST" action="/logout" style="margin:0;">
                @csrf
                <button type="submit" style="background:#197080; color:#fff; border:none; padding:10px 28px; border-radius:7px; font-size:17px; font-weight:600; cursor:pointer;">Logout</button>
            </form>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    @if($isEmployer)
                        <div style="text-align:center; margin-bottom: 32px;">
                            <h1 style="font-size: 32px; font-weight: bold; color: #197080; margin-bottom: 18px;">POST YOUR FIRST JOB IN MINUTES!</h1>
                            <div style="font-size: 20px; color: #197080; margin-bottom: 18px;">Looking for assistance? Call: 0800-76933 (quickhire)</div>
                            <a href="/jobs/create" style="display:inline-block; background:#197080; color:#fff; font-size:20px; font-weight:600; padding:14px 38px; border-radius:8px; text-decoration:none; margin-top:18px;">Post a Job</a>
                        </div>
                        <h2 style="font-size: 24px; color: #197080; margin-bottom: 16px; text-align:left;">Your Posted Jobs</h2>
                        @if($jobs->count())
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                @foreach($jobs as $job)
                                    <div class="bg-white border rounded shadow p-4 flex flex-col">
                                        <div class="flex items-center mb-2">
                                            <h2 class="text-lg font-bold text-green-800">{{ $job->job_title }}</h2>
                                        </div>
                                        <hr class="mb-2">
                                        <div class="mb-1 text-gray-700">{{ $job->location }} | {{ $job->industry }}</div>
                                        <div class="mb-1 text-gray-600">Posted: {{ $job->created_at->diffForHumans() }}</div>
                                        <div class="mb-1 text-gray-600">Positions: {{ $job->positions }}</div>
                                        <div class="mb-1 text-gray-600">Start Date: {{ $job->start_date ?? '-' }}</div>
                                        <div class="mb-1 text-gray-600">Last Date: {{ $job->last_date_to_apply ?? '-' }}</div>
                                        <div class="flex gap-2 mt-4">
                                            <a href="#" class="bg-teal-900 text-white px-3 py-1 rounded text-sm">View Job</a>
                                        </div>
                                    </div>
                                    <div class="bg-gray-50 border rounded shadow p-4 mt-2 mb-6">
                                        <strong>Applicants:</strong>
                                        @php($applications = \App\Models\JobApplication::where('job_id', $job->id)->with('user')->get())
                                        @if($applications->count())
                                            <ul class="mt-2 space-y-2">
                                                @foreach($applications as $app)
                                                    <li class="bg-gray-100 rounded px-3 py-2 text-[#197080] shadow-sm">
                                                        {{ $app->user->email ?? 'N/A' }} - {{ $job->job_title }}
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @else
                                            <span class="text-gray-500">No applicants yet.</span>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div style="color:#888;">No jobs posted yet.</div>
                        @endif
                    @else
                        <h2 style="font-size: 24px; color: #197080; margin-bottom: 16px; text-align:left;">Latest Jobs</h2>
                        @if($jobs->count())
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                @foreach($jobs as $job)
                                    <div class="bg-gray-100 rounded-lg p-6 shadow">
                                        <div class="text-xl font-semibold text-[#197080]">{{ $job->job_title }}</div>
                                        <div class="text-gray-700">{{ $job->location }} | {{ $job->industry }} | {{ $job->positions }} Position(s)</div>
                                        <div class="text-gray-500 text-sm">Posted: {{ $job->created_at->diffForHumans() }}</div>
                                        <div class="text-gray-600 text-sm">Start Date: {{ $job->start_date ?? '-' }}</div>
                                        <div class="text-gray-600 text-sm">Last Date to Apply: {{ $job->last_date_to_apply ?? '-' }}</div>
                                        <form method="POST" action="/jobs/{{ $job->id }}/apply" class="mt-3 inline-block">
                                            @csrf
                                            <button type="submit" class="bg-blue-500 text-black px-4 py-2 rounded font-semibold text-base hover:bg-blue-700 transition">Apply Now</button>
                                        </form>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div style="color:#888;">No jobs available yet.</div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
