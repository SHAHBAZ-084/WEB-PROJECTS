<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Your First Job</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:700,400&display=swap" rel="stylesheet">
    <style>
        body { background: #f5f7fa; font-family: 'Roboto', Arial, sans-serif; margin: 0; }
        .container { max-width: 900px; margin: 40px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 16px #e0e0e0; padding: 40px 40px 32px 40px; }
        h1 { color: #197080; font-size: 36px; margin-bottom: 10px; text-align: center; }
        .subheading { color: #197080; font-size: 22px; margin-bottom: 30px; text-align: center; }
        label { font-size: 22px; color: #197080; font-weight: 500; display: block; margin-bottom: 8px; margin-top: 24px; }
        input[type="text"] { width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px; margin-bottom: 10px; }
        textarea { width: 100%; min-height: 200px; font-size: 18px; border: 2px solid #197080; border-radius: 4px; padding: 12px; resize: vertical; }
        .btn-submit { background: #197080; color: #fff; font-size: 20px; font-weight: 600; border: none; border-radius: 8px; padding: 14px 38px; margin-top: 30px; cursor: pointer; display: block; margin-left: auto; margin-right: auto; }
        .required { color: #e74c3c; font-size: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>POST YOUR FIRST JOB IN MINUTES!</h1>
        <div class="subheading">Looking for assistance? Call: 0800-76933 (quickhire)</div>
        <img src="/a.jpg" alt="Job Image" style="width:100%; height:auto; border-radius:50%; display:block; margin:auto;">
        <form method="POST" action="/jobs">
            <?php echo csrf_field(); ?>
            <label for="job_title">Job Title<span class="required">*</span></label>
            <input type="text" id="job_title" name="job_title" required>

            <label for="job_description">Job Description<span class="required">*</span></label>
            <textarea id="job_description" name="job_description" required></textarea>

            <label for="skills">What skills are required for this job? <span class="required">*</span></label>
            <input type="text" id="skills" name="skills" placeholder="e.g. PHP, SEO, Marketing" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px; margin-bottom: 10px;">
            <div style="text-align:right; color:#888; font-size:14px; margin-bottom: 10px;">Max. 20 skills allowed</div>

            <div style="display: flex; gap: 24px;">
                <div style="flex:1;">
                    <label for="career_level">Required career level for this job?<span class="required">*</span></label>
                    <select id="career_level" name="career_level" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Choose career level</option>
                        <option value="entry">Entry Level</option>
                        <option value="mid">Mid Level</option>
                        <option value="senior">Senior Level</option>
                        <option value="manager">Manager</option>
                    </select>
                </div>
                <div style="flex:1;">
                    <label for="positions">No. of Positions<span class="required">*</span></label>
                    <input type="number" id="positions" name="positions" min="1" value="1" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                </div>
            </div>

            <label for="location">Job Location<span class="required">*</span></label>
            <input type="text" id="location" name="location" placeholder="Select multiple cities" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px; margin-bottom: 10px;">
            <div style="text-align:right; color:#888; font-size:14px; margin-bottom: 10px;">Not in Pakistan</div>

            <div style="display: flex; gap: 24px;">
                <div style="flex:1;">
                    <label for="qualification">What minimum qualification is required?<span class="required">*</span></label>
                    <select id="qualification" name="qualification" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Select degree level</option>
                        <option value="matric">Matric</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="bachelor">Bachelor</option>
                        <option value="master">Master</option>
                        <option value="phd">PhD</option>
                    </select>
                </div>
                <div style="flex:1;">
                    <label for="qualification_level">&nbsp;</label>
                    <select id="qualification_level" name="qualification_level" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px; margin-top: 8px;">
                        <option value="">or higher</option>
                        <option value="exact">Exact</option>
                        <option value="or_higher">Or Higher</option>
                    </select>
                </div>
            </div>

            <label>Years of experience required? <span class="required">*</span></label>
            <div style="display: flex; gap: 24px;">
                <div style="flex:1;">
                    <select id="min_experience" name="min_experience" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Min</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10+</option>
                    </select>
                </div>
                <div style="flex:1;">
                    <select id="max_experience" name="max_experience" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Max</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10+</option>
                    </select>
                </div>
            </div>

            <label for="start_date">Job Start Date<span class="required">*</span></label>
            <input type="date" id="start_date" name="start_date" required>

            <label for="last_date">Last Date to Apply<span class="required">*</span></label>
            <input type="date" id="last_date" name="last_date" required>

            <div style="display: flex; gap: 24px;">
                <div style="flex:1;">
                    <label for="industry">Choose industry<span class="required">*</span></label>
                    <select id="industry" name="industry" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Choose industry*</option>
                        <option value="it">IT</option>
                        <option value="education">Education</option>
                        <option value="health">Health</option>
                        <option value="finance">Finance</option>
                        <option value="manufacturing">Manufacturing</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div style="flex:1;">
                    <label for="functional_area">Functional Area<span class="required">*</span></label>
                    <select id="functional_area" name="functional_area" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">Functional Area</option>
                        <option value="development">Development</option>
                        <option value="design">Design</option>
                        <option value="marketing">Marketing</option>
                        <option value="hr">HR</option>
                        <option value="sales">Sales</option>
                        <option value="other">Other</option>
                    </select>
                </div>
            </div>

            <label>What is the salary range? <span class="required">*</span></label>
            <div style="display: flex; gap: 24px;">
                <div style="flex:1;">
                    <select id="salary_from" name="salary_from" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">From</option>
                        <option value="10000">10,000</option>
                        <option value="20000">20,000</option>
                        <option value="30000">30,000</option>
                        <option value="40000">40,000</option>
                        <option value="50000">50,000</option>
                        <option value="100000">100,000</option>
                        <option value="200000">200,000</option>
                    </select>
                </div>
                <div style="flex:1;">
                    <select id="salary_to" name="salary_to" required style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px;">
                        <option value="">To</option>
                        <option value="20000">20,000</option>
                        <option value="30000">30,000</option>
                        <option value="40000">40,000</option>
                        <option value="50000">50,000</option>
                        <option value="100000">100,000</option>
                        <option value="200000">200,000</option>
                        <option value="500000">500,000</option>
                    </select>
                </div>
            </div>

            <div style="margin: 18px 0 10px 0;">
                <span>Should the salary be visible in your job post?</span>
                <label style="margin-left: 18px; font-size: 18px;"><input type="radio" name="salary_visible" value="yes" style="margin-right: 6px;"> Yes</label>
                <label style="margin-left: 18px; font-size: 18px;"><input type="radio" name="salary_visible" value="no" checked style="margin-right: 6px;"> No</label>
            </div>

            <label for="gender_pref">Is there a gender preference for this job?</label>
            <select id="gender_pref" name="gender_pref" style="width: 100%; padding: 14px; font-size: 20px; border: 2px solid #197080; border-radius: 4px; margin-bottom: 18px;">
                <option value="">No Preference</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <div style="margin-bottom: 18px;">
                <label style="font-size: 20px;">
                    <input type="checkbox" name="custom_questions" style="margin-right: 8px;"> Screen your applicants further with custom questions
                    <span style="color: #197080; font-size: 16px; margin-left: 8px; cursor: pointer;" title="Learn more">&#9432; Learn more</span>
                </label>
            </div>

            <div style="margin-bottom: 18px;">
                <label style="font-size: 16px; display: flex; align-items: flex-start;">
                    <input type="checkbox" name="authorize" required style="margin-right: 8px; margin-top: 4px;">
                    <span>I authorize quickhire to post jobs of my company on its website. No other online mediums are authorized to post these jobs without the explicit approval of my company or quickhire. Moreover, I agree to abide by the quickhire Terms of Services</span>
                </label>
            </div>

            <button type="submit" class="btn-submit">Post Job</button>
        </form>
    </div>
</body>
</html> <?php /**PATH C:\xampp\htdocs\quickhire\resources\views/jobs/create.blade.php ENDPATH**/ ?>