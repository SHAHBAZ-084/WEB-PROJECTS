<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>quickhire</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:700,400&display=swap" rel="stylesheet">
            <style>
        body {
            margin: 0;
            font-family: 'Roboto', Arial, sans-serif;
            background: #007080;
        }
        .header {
            width: 100%;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 60px 18px 36px;
            box-sizing: border-box;
            border-bottom: 2px solid #e0e0e0;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
        }
        .header .left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .header .logo {
            height: 72px;
            width: 72px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            object-fit: cover;
        }
        .header .brand {
            font-size: 38px;
            font-weight: bold;
            color: #197080;
            margin-left: 12px;
            letter-spacing: 1px;
        }
        .header .nav {
            display: flex;
            gap: 16px;
        }
        .header .nav a, .header .nav button {
            background: #007080;
            color: #fff;
            border: none;
            padding: 12px 38px;
            border-radius: 8px;
            font-size: 20px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.2s, color 0.2s, border 0.2s;
            box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        }
        .header .nav button {
            background: #fff;
            color: #007080;
            border: 2px solid #007080;
        }
        .header .nav a:hover, .header .nav button:hover {
            background: #005f6b;
            color: #fff;
            border-color: #005f6b;
        }
        .header .right-logo {
            height: 60px;
        }
        .main-section {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 80vh;
            padding: 40px 0;
        }
        .main-content {
            flex: 1;
            max-width: 700px;
            color: #fff;
            padding-left: 60px;
        }
        .main-content h1 {
            font-size: 60px;
            font-weight: 700;
            margin: 0 0 10px 0;
            line-height: 1.1;
        }
        .main-content h2 {
            font-size: 48px;
            font-weight: 700;
            margin: 0 0 30px 0;
            line-height: 1.1;
        }
        .main-content .subtitle {
            font-size: 18px;
            margin-bottom: 30px;
        }
        .search-bar {
            display: flex;
            max-width: 400px;
            background: #fff;
            border-radius: 6px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.07);
        }
        .search-bar input {
            flex: 1;
            border: none;
            padding: 15px;
            font-size: 16px;
            outline: none;
        }
        .search-bar button {
            background: #007080;
            color: #fff;
            border: none;
            padding: 0 25px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }
        .search-bar button:hover {
            background: #005f6b;
        }
        .main-image {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .main-image .circle {
            width: 400px;
            height: 400px;
            background: radial-gradient(circle at 60% 40%, #00bfae 60%, #007080 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            box-shadow: 0 4px 32px rgba(0,0,0,0.10);
        }
        .main-image img {
            width: 90%;
            border-radius: 20px;
            object-fit: cover;
        }
        @media (max-width: 900px) {
            .main-section {
                flex-direction: column;
                padding: 20px 0;
            }
            .main-content {
                padding-left: 0;
                text-align: center;
            }
            .main-image {
                margin-top: 40px;
            }
        }
            </style>
    </head>
<body>
    <div class="header">
        <div class="left">
            <img src="/quickhire.jpg" alt="quickhire Logo" class="logo">
            <span class="brand">Quickhire</span>
        </div>
        <div class="nav">
            <a href="/register">Register Yourself</a>
            <button onclick="window.location='/login'">Login</button>
        </div>
    </div>
    <div class="main-section">
        <div class="main-content">
            <h1>Quickly start your</h1>
            <h2>Professions</h2>
            <div class="subtitle">One Platform For Job Seekers And Employers</div>
            <form class="search-bar" action="/register" method="get">
                <input type="text" placeholder="@keyword" />
                <button type="submit">Find Jobs</button>
            </form>
        </div>
        <div class="main-image">
            <div class="circle">
                <img src="/a.jpg" alt="Group Photo" />
            </div>
        </div>
    </div>
    <!-- Statistics Section -->
    <div style="background: #fafbfc; padding: 40px 0 30px 0;">
        <h1 style="text-align:center; font-size: 44px; font-weight: 700; letter-spacing: 1px; color: #007080; margin: 0 0 10px 0;">
            <span style="color: #000;">OUR</span> <span style="color: #007080;">STATISTICS</span>
        </h1>
        <div style="text-align:center; color: #197080; font-size: 20px; margin-bottom: 30px; margin-top: 10px;">
            To Choose Your Trending Job Dream & To Make Future Bright.
        </div>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; max-width: 1400px; margin: 0 auto;">
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128188;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Cumulative Jobs</div>
                <div style="font-size: 18px; margin-top: 5px;">87527</div>
            </div>
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128100;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Cumulative Employers</div>
                <div style="font-size: 18px; margin-top: 5px;">304</div>
            </div>
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128196;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Resume & Job Seekers</div>
                <div style="font-size: 18px; margin-top: 5px;">704</div>
            </div>
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128188;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Overseas Jobs</div>
                <div style="font-size: 18px; margin-top: 5px;">86501</div>
            </div>
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128188;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Government Jobs</div>
                <div style="font-size: 18px; margin-top: 5px;">1026</div>
            </div>
            <div style="background: #fff; border-radius: 6px; box-shadow: 0 2px 8px #e6f5ee; min-width: 200px; flex: 1 1 200px; max-width: 220px; padding: 20px; text-align: center; border: 1px solid #e6f5ee;">
                <div style="background: #e6f0fa; display: inline-block; border-radius: 50%; padding: 8px; margin-bottom: 8px;">
                    <span style="font-size: 22px; color: #197080;">&#128188;</span>
                </div>
                <div style="font-weight: bold; color: #009688; font-size: 20px;">Private Jobs</div>
                <div style="font-size: 18px; margin-top: 5px;">0</div>
            </div>
        </div>
    </div>
    <!-- For Jobseekers Section -->
    <div style="background: #00687a; color: #fff; text-align: center; padding: 60px 0 40px 0; margin-top: 0;">
        <h1 style="font-size: 44px; font-weight: 700; margin-bottom: 10px;">For Jobseekers</h1>
        <div style="font-size: 24px; font-weight: bold; margin-bottom: 10px;">HOW IT WORKS <span style="font-weight: 400; font-size: 22px;">: If You're Seeking The Right Job, Follow These Steps.</span></div>
    </div>
    <!-- Top Jobs Section -->
    <div style="background: #fff; padding: 40px 0 60px 0;">
        <h1 style="text-align:center; font-size: 44px; font-weight: 700; letter-spacing: 1px; color: #007080; margin: 0 0 10px 0;">
            <span style="color: #000;">OUR</span> <span style="color: #007080;">TOP JOBS</span>
        </h1>
        <div style="text-align:center; color: #197080; font-size: 24px; margin-bottom: 30px; margin-top: 10px;">
            Here We Have Some Of Our Top Jobs, You Can Explore Here
        </div>
        <div style="display: flex; justify-content: center; gap: 10px; margin-bottom: 30px;">
            <button style="background: #007080; color: #fff; border: none; padding: 8px 28px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer;">Government</button>
            <button style="background: #fff; color: #007080; border: none; padding: 8px 28px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer;">Private</button>
            <button style="background: #fff; color: #007080; border: none; padding: 8px 28px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer;">Overseas</button>
        </div>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; max-width: 1400px; margin: 0 auto;">
            <!-- Job Card 1 -->
            <div style="background: #fff; border-radius: 4px; box-shadow: 0 2px 8px #d3dbe3; min-width: 320px; max-width: 340px; flex: 1 1 320px; padding: 20px 18px 18px 18px; text-align: left; border: 2px solid #d3dbe3; margin-bottom: 10px;">
                <div style='font-size: 40px; text-align: center; margin-bottom: 8px;'>💼</div>
                <div style="font-weight: bold; color: #007080; font-size: 22px; text-align: center; margin-bottom: 8px;">Director General</div>
                <hr style="margin: 10px 0;">
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">National Vocational And Technical Training Comission</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Deadline: 06/07/2025</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Location: Islamabad</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Scale:BPS-20</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 12px;">Total Vacancies: 1</div>
                <button style="background: #fff; color: #e74c3c; border: 1px solid #e74c3c; border-radius: 4px; padding: 4px 14px; font-size: 14px; margin-right: 8px;">Expired</button>
                <button style="background: #007080; color: #fff; border: none; border-radius: 4px; padding: 4px 18px; font-size: 14px; font-weight: 600;">View Job</button>
            </div>
            <!-- Job Card 2 -->
            <div style="background: #fff; border-radius: 4px; box-shadow: 0 2px 8px #d3dbe3; min-width: 320px; max-width: 340px; flex: 1 1 320px; padding: 20px 18px 18px 18px; text-align: left; border: 2px solid #d3dbe3; margin-bottom: 10px;">
                <div style='font-size: 40px; text-align: center; margin-bottom: 8px;'>💼</div>
                <div style="font-weight: bold; color: #009688; font-size: 20px; text-align: center; margin-bottom: 8px;">Technical Trade Instructor Stitching/Fashion Designing</div>
                <hr style="margin: 10px 0;">
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">National Vocational And Technical Training Comission</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Deadline: 04/09/2025</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Location: Islamabad</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Scale:Fixed-Pay</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 12px;">Total Vacancies: 8</div>
                <button style="background: #fff; color: #e74c3c; border: 1px solid #e74c3c; border-radius: 4px; padding: 4px 14px; font-size: 14px; margin-right: 8px;">Expired</button>
                <button style="background: #007080; color: #fff; border: none; border-radius: 4px; padding: 4px 18px; font-size: 14px; font-weight: 600;">View Job</button>
            </div>
            <!-- Job Card 3 -->
            <div style="background: #fff; border-radius: 4px; box-shadow: 0 2px 8px #d3dbe3; min-width: 320px; max-width: 340px; flex: 1 1 320px; padding: 20px 18px 18px 18px; text-align: left; border: 2px solid #d3dbe3; margin-bottom: 10px;">
                <div style='font-size: 40px; text-align: center; margin-bottom: 8px;'>💼</div>
                <div style="font-weight: bold; color: #009688; font-size: 20px; text-align: center; margin-bottom: 8px;">Technical Trade Instructor General Electrician</div>
                <hr style="margin: 10px 0;">
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">National Vocational And Technical Training Comission</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Deadline: 04/09/2025</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Location: Islamabad</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Scale:Fixed-Pay</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 12px;">Total Vacancies: 5</div>
                <button style="background: #fff; color: #e74c3c; border: 1px solid #e74c3c; border-radius: 4px; padding: 4px 14px; font-size: 14px; margin-right: 8px;">Expired</button>
                <button style="background: #007080; color: #fff; border: none; border-radius: 4px; padding: 4px 18px; font-size: 14px; font-weight: 600;">View Job</button>
            </div>
            <!-- Job Card 4 -->
            <div style="background: #fff; border-radius: 4px; box-shadow: 0 2px 8px #d3dbe3; min-width: 320px; max-width: 340px; flex: 1 1 320px; padding: 20px 18px 18px 18px; text-align: left; border: 2px solid #d3dbe3; margin-bottom: 10px;">
                <div style='font-size: 40px; text-align: center; margin-bottom: 8px;'>💼</div>
                <div style="font-weight: bold; color: #009688; font-size: 20px; text-align: center; margin-bottom: 8px;">Technical Trade Instructor Plumbing</div>
                <hr style="margin: 10px 0;">
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">National Vocational And Technical Training Comission</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Deadline: 04/09/2025</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Location: Islamabad</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 6px;">Scale:Fixed-Pay</div>
                <div style="font-size: 15px; color: #222; margin-bottom: 12px;">Total Vacancies: 5</div>
                <button style="background: #fff; color: #e74c3c; border: 1px solid #e74c3c; border-radius: 4px; padding: 4px 14px; font-size: 14px; margin-right: 8px;">Expired</button>
                <button style="background: #007080; color: #fff; border: none; border-radius: 4px; padding: 4px 18px; font-size: 14px; font-weight: 600;">View Job</button>
            </div>
        </div>
    </div>
    <!-- Browse All Jobs Button -->
    <div style="background: #fff; padding: 30px 0 0 0; text-align: center;">
        <button style="background: #007080; color: #fff; border: none; border-radius: 8px; padding: 16px 48px; font-size: 22px; font-weight: 700; box-shadow: 0 2px 8px #d3dbe3; cursor: pointer; margin-bottom: 20px;">Browse All Jobs</button>
    </div>
    <!-- Footer -->
    <footer style="background: #00687a; color: #fff; padding: 40px 0 0 0; margin-top: 0;">
        <div style="max-width: 1400px; margin: 0 auto; display: flex; flex-wrap: wrap; justify-content: space-between;">
            <div style="flex: 1 1 220px; min-width: 200px; margin-bottom: 20px;">
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 12px;">quickhire</div>
                <div style="margin-bottom: 6px;"><a href="#" style="color: #fff; text-decoration: none; margin-right: 18px;">About Us</a> <a href="#" style="color: #fff; text-decoration: none;">Contact Us</a></div>
                <div><a href="#" style="color: #fff; text-decoration: none;">Our Services</a></div>
            </div>
            <div style="flex: 1 1 220px; min-width: 200px; margin-bottom: 20px;">
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 12px;">Quick Links</div>
                <div style="margin-bottom: 6px;"><a href="#" style="color: #fff; font-weight: 700; text-decoration: none; margin-right: 18px;">Sign Up (JobSeeker)</a></div>
                <div style="margin-bottom: 6px;"><a href="#" style="color: #fff; font-weight: 700; text-decoration: none; margin-right: 18px;">Sign Up (Employer)</a> <a href="#" style="color: #fff; text-decoration: none;">Sign In</a></div>
                <div style="margin-bottom: 6px;"><a href="#" style="color: #fff; text-decoration: none; margin-right: 18px;">Find A Job</a> <a href="#" style="color: #fff; text-decoration: none;">Help Center</a></div>
            </div>
            <div style="flex: 1 1 220px; min-width: 200px; margin-bottom: 20px;">
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 12px;">Contact</div>
                <div style="margin-bottom: 6px;"> <span style="font-size: 18px;">&#128205;</span> Plot No 38, Kirthar Road, H-9/4,<br> Islamabad, Pakistan</div>
                <div style="margin-bottom: 6px;"> <span style="font-size: 18px;">&#128222;</span> 0800 88866</div>
                <div style="margin-bottom: 6px;"> <span style="font-size: 18px;">&#9993;</span> Info@Jobs.Gov.Pk</div>
            </div>
            <div style="flex: 1 1 320px; min-width: 250px; margin-bottom: 20px;">
                <div style="font-size: 18px; font-weight: 600; margin-bottom: 12px;">quickhire</div>
                <div style="font-size: 14px; color: #cce6ea;">Developed With The Technical Assistance Of TVET SSP (Funded By European Union, Federal Republic Of Germany And Royal Norwegian Embassy And Implemented By GIZ)</div>
            </div>
        </div>
        <div style="text-align: center; padding: 18px 0 12px 0; font-size: 16px; color: #fff;">
            <div style="font-weight: 700;">quickhire - Job Portal</div>
            <div style="font-size: 15px; color: #cce6ea;">© <a href="#" style="color: #fff; text-decoration: underline;">quickhire</a>, All Right Reserved. Designed By <a href="#" style="color: #fff; text-decoration: underline;">NSIS quickhire</a></div>
        </div>
    </footer>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\quickhire\resources\views/welcome.blade.php ENDPATH**/ ?>