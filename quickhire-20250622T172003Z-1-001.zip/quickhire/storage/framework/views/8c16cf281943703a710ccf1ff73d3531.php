<?php ($customBg = 'background: #f5f7fa; min-height: 100vh;'); ?>
<div style="<?php echo e($customBg); ?> display: flex; align-items: center; justify-content: center;">
    <div style="max-width: 600px; width: 100%; margin: 40px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 16px #e0e0e0; padding: 32px 32px 18px 32px;">
        <div style="text-align: center; margin-bottom: 18px;">
            <img src="/quickhire.jpg" alt="quickhire Logo" style="height: 80px; margin-bottom: 10px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <div style="font-size: 28px; font-weight: bold; color: #197080; margin-bottom: 4px; letter-spacing: 1px;">Welcome back!</div>
            <div style="font-size: 18px; color: #555; margin-bottom: 18px;">Sign in to your account to continue</div>
        </div>
        <!-- Session Status -->
        <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <!-- Email Address -->
            <div style="margin-bottom: 16px;">
                <label for="email" style="display:block; font-weight:500; margin-bottom:6px;">Email</label>
                <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autofocus style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="color:#e74c3c; font-size:13px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Password -->
            <div style="margin-bottom: 16px;">
                <label for="password" style="display:block; font-weight:500; margin-bottom:6px;">Password</label>
                <input id="password" name="password" type="password" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="color:#e74c3c; font-size:13px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <!-- Remember Me -->
            <div style="margin-bottom: 16px; display: flex; align-items: center;">
                <input id="remember_me" type="checkbox" name="remember" style="margin-right: 8px;">
                <label for="remember_me" style="font-size: 15px; color: #333;">RememberMe</label>
            </div>
            <button type="submit" style="width:100%; background:#00687a; color:#fff; border:none; border-radius:6px; padding:12px 0; font-size:18px; font-weight:600; margin-bottom:10px;">Login</button>
            <?php if(Route::has('password.request')): ?>
                <div style="margin-top: 6px;">
                    <a href="<?php echo e(route('password.request')); ?>" style="color:#00687a; text-decoration:underline; font-size: 15px;">Forgot Password?</a>
                </div>
            <?php endif; ?>
        </form>
        <div style="text-align:center; margin-top: 18px; font-size: 15px;">
            Don't have an account? <a href="#" style="color:#00687a; font-weight:600; text-decoration:underline;">Sign up as JobSeeker</a> / <a href="<?php echo e(route('register')); ?>" style="color:#00687a; font-weight:600; text-decoration:underline;">Sign up as Employer</a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\quickhire\resources\views/auth/login.blade.php ENDPATH**/ ?>